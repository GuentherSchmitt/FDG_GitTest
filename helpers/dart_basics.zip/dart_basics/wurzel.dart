import 'dart:math';

void main(List<String> args) {
  for (var arg in args) {
    double? d = double.tryParse(arg);
    if (d == null) {
      print("argument $arg is not a number");
    } else {
      print("square root of $arg is ${sqrt(d)}.");
    }
  }
}

double mySqrt(double x) {
  if (x < 0) {
    return double.nan;
  }
  if (x == 0) {
    return 0;
  }
  if (x == 1) {
    return 1;
  }
  double a = 1;
  double e = x;
  if (x < 1) {
    a = x;
    e = 1;
  }

  int loopCount = 1;
  while (loopCount < 10000) {
    double test = a + (e - a) / 2;
    double square = test * test;
    if (square == x) {
      print("equality reached in loop $loopCount: test=$test, square=$square");
      return test;
    }
    //print("loop $loopCount: a=$a, e=$e, test=$test, square=$square");
    if (square < x) {
      a = test;
    } else {
      e = test;
    }
    if ((square - x).abs() < 0.000000000001) {
      print("approximate square root found in loop $loopCount: test=$test, square=$square");
      return test;
    }
    loopCount++;
  }
  print("mySqrt: end of while loop reached !?!?");
  return double.nan;
}
