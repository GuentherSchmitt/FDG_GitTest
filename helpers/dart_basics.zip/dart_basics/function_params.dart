void main() {
  //testPositionalParams();
  //testNamedParams();
  testPositionalAndNamedParams();
}

// --- test positional parameters ---

void testPositionalParams() {
  usePositionalParams(1, 1.5, "hello");
  //usePositionalParams(1, 0.5); // 3 positional arguments expected by 'usePositionalParams', but 2 found.

  useOptionalPositionalParam(2, 2.5);
  useOptionalPositionalParam(2, 2.5, "hi");

  useNullableOptionalPositionalParam(3, 3.3);
  useNullableOptionalPositionalParam(3, 3.3, "servus");
}

void usePositionalParams(int i, double d, String s) {
  print("usePositionalParams: i: $i, d: $d, s: $s");
}

void useOptionalPositionalParam(int i, double d, [String s = "abc"]) {
  print("useOptionalPositionalParam: i: $i, d: $d, s: $s");
}

void useNullableOptionalPositionalParam(int i, double d, [String? s]) {
  print("useNullableOptionalPositionalParam: i: $i, d: $d, s: $s");
}

// more than one optional parameter:
void useSeveralOptionalPositionalParams(int i, [double? d , String? s]) {
  print("useSeveralOptionalPositionalParams: i: $i, d: $d, s: $s");
}

// --- test named parameters ---

void testNamedParams() {
  //useNamedParameters();  // error: The named parameter 'i' is required, but there's no corresponding argument.

   useNamedParams(i: 3);
   useNamedParams(d: 2.5, i: 5);
   useNamedParams(i: -1, d: 5, s: "hi");
}

void useNamedParams({required int? i, double? d, String s = 'test'}) {
  print("useNamedParams: i: $i, d: $d, s: $s");
  if (d != null && d < 4) {
    print('BTW: d was less than 4');
  }
}

// --- test positional and named parameters ---

void testPositionalAndNamedParams() {
  //usePositionalAndNamedParams(i: 1, d: 0.5);  // error: The named parameter 'i' isn't defined.
  //usePositionalAndNamedParams(d: 0.5);        // error: 1 positional argument expected, but 0 found.

  usePositionalAndNamedParams(3, d: 3.3);
  usePositionalAndNamedParams(10, s: "hello", d: 9);
}

void usePositionalAndNamedParams(int i, {required double d, String s = "abc"}) {
  print ("usePositionalAndNamedParams: i: $i, d: $d, s: $s");
}

