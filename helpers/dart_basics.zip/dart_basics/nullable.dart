// ignore_for_file: unused_local_variable

void main(List<String> args) {
  foo2(null);      // prints "null"
  foo2("Hello");   // prints "hello"
}

void foo2(String? s) {
  print(s?.toLowerCase());               
  
  //String lower = s?.toLowerCase();     // compile-error
  String? lower = s?.toLowerCase();  
}

void foo1(String? s) {
  // print(s.toLowerCase());
}

void foo(String s) {
  print(s.toLowerCase());
}

void foo4(String? s) {
  if (s == null) {
    return;
  }
  // compiler knows taht s is not null now !
  s.toLowerCase();
}
